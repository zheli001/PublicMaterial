# Royal Bayview Client Discovery Questionnaire

## Personal Information
- Full Name:
- Phone Number:
- Email Address:
- Current Address:

## Lifestyle Preferences
- Are you a golfer? (Yes/No/Interested in learning)
- What activities are important to you? (Fitness, social events, etc.)
- Do you entertain frequently? (Yes/No/Occasionally)

## Housing Requirements
- Preferred suite size: (1 bedroom / 2 bedroom / 3 bedroom)
- Must-have features:
- Nice-to-have features:
- Budget range:

## Timeline
- When are you looking to move?
- Are you currently renting or do you own?
- Any flexibility in timeline?

## Additional Questions
- Any specific concerns or requirements?
- Questions about the building or neighborhood?

## Contact Preferences
- Best way to reach you:
- Preferred communication times:
- Would you like virtual or in-person tours?

---
Thank you for your interest in Royal Bayview!
We will contact you within 24 hours to discuss your requirements.
